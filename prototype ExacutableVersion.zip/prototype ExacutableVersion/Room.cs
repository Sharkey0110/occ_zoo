﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prototype
{
    internal class Room
    {
        public int _roomId { get; set; }
        public int _userId { get; set; }
        public string _roomType { get; set; }
        public DateTime _startDate { get; set; }
        public DateTime _endDate { get; set; }
        public int _duration { get; set; }
        public decimal _dayPrice { get; set; }
        public decimal _totalPrice { get; set; }
        public bool _paidWithMoney { get; set; }


        public List<Room> bookedRooms = new List<Room>();


        //SQL for rooms table
        private decimal getRoomPrice(int roomNum, SqlConnection sqlConnection)
        {
            //connect to Database
            SqlCommand sqlCommand = new SqlCommand("GetRoomPrice", sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            //Pass in params
            sqlCommand.Parameters.AddWithValue("@RoomNum", roomNum);

            //execute
            sqlConnection.Open();
            SqlDataReader reader = sqlCommand.ExecuteReader();

            //Store the data
            decimal price = 0;
            while (reader.Read())
            {
                price = (decimal)(reader["DayPrice"]);
            }
            sqlConnection.Close();
            return price;
        }

        public List<Room> getRooms(SqlConnection sqlConnection)
        {
            List<Room> rooms = new List<Room>();
            //connect to Database
            SqlCommand sqlCommand = new SqlCommand("GetAvailableRooms", sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            //exucute
            sqlConnection.Open();

            SqlDataReader reader = sqlCommand.ExecuteReader();
            //Pass data into user class
            while (reader.Read())
            {
                rooms.Add(new Room
                {
                    _roomId = (int)reader["RoomNum"],
                    _roomType = reader["RoomType"].ToString(),
                    _dayPrice = (decimal)reader["DayPrice"]
                });
            }
            sqlConnection.Close();
            return rooms;
        }

        public void bookRooms(SqlConnection sqlConnection)
        {
            foreach(Room room in bookedRooms)
            {
                //connect to database
                SqlCommand sqlCommand = new SqlCommand("BookRooms", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                //Pass in params
                sqlCommand.Parameters.AddWithValue("@RoomNum", room._roomId);
                sqlCommand.Parameters.AddWithValue("@User", room._userId);
                sqlCommand.Parameters.AddWithValue("@StartDate", room._startDate);
                sqlCommand.Parameters.AddWithValue("@EndDate", room._endDate);
                sqlCommand.Parameters.AddWithValue("@Duration", room._duration);
                sqlCommand.Parameters.AddWithValue("@TotalPrice", room._totalPrice);
                sqlCommand.Parameters.AddWithValue("@PaidWithMoney", room._paidWithMoney);

                //exucute
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
            }
            MessageBox.Show("All rooms booked sucessfully");
        }

        //FUNCTIONS

        public (string, string) updateRoomPrice(string availableRoomsBox, DateTime roomStartDate, DateTime roomEndDate, string roomMoneyPrice, string roomPointsPrice, SqlConnection sqlConnection)
        {
            try
            {
                roomMoneyPrice = "Money Price: ";
                roomPointsPrice = "Points Price: ";

                //only display price if a room is selected
                if (!string.IsNullOrEmpty(availableRoomsBox))
                {
                    string room = availableRoomsBox;
                    int roomNum = int.Parse(availableRoomsBox.Split(' ')[1]);

                    decimal price = getRoomPrice(roomNum, sqlConnection);

                    //Specify variables
                    int duration;

                    //Fill variables with default or user input data
                    if (roomStartDate == null | roomEndDate == null)
                    {
                        duration = 1;
                    }
                    else
                    {
                        //Check if dates are impossible, enddate before startdate
                        if (roomStartDate > roomEndDate.AddDays(1))
                        {
                            MessageBox.Show("Ensure Start date is before end date 1");
                            return (roomMoneyPrice, roomPointsPrice);
                        }
                        duration = (roomEndDate.Date - roomStartDate.Date).Days + 1;
                    }
                    {
                        //Calculate and display price
                        roomMoneyPrice = "Money Price: " + (duration * price).ToString("C", CultureInfo.CurrentCulture);
                        roomPointsPrice = "Points Price: " + (int)(duration * price * 10);
                        return (roomMoneyPrice, roomPointsPrice);
                    }
                }
                return (roomMoneyPrice, roomPointsPrice);
            }
            catch
            {
                MessageBox.Show("Error");
                return (roomMoneyPrice, roomPointsPrice);
            }
        }

        public void addRoomToList(DateTime startDate, DateTime endDate, string roomDetails, int userId, bool payWithMoney, SqlConnection sqlConnection)
        {
            //gather data 
            int duration;
            if (endDate == null)
            {
                duration = 1;
            }
            else if (startDate > endDate.AddDays(1))
            {
                return;
            } 
            else
            {
                duration = (endDate.Date - startDate.Date).Days + 1;
            }
            int roomNum = int.Parse(roomDetails.Split(' ')[1]);
            decimal price = getRoomPrice(roomNum, sqlConnection);

            decimal totalPrice = duration * price;

            //add room to list
            bookedRooms.Add(new Room
            {
                _roomId = roomNum,
                _userId = userId,
                _startDate = startDate,
                _endDate = endDate,
                _totalPrice = totalPrice,
                _duration = duration,
                _paidWithMoney = payWithMoney,
            });
        }

        public void removeRoomFromList(int roomNum)
        {
            bookedRooms = bookedRooms.Where(room => room._roomId != roomNum).ToList();
        }

        public decimal calculateMoneyOrPoints(string type)
        {
            decimal amount = 0;

            if(type == "points")
            {
                foreach (Room room in bookedRooms)
                {
                    if (!room._paidWithMoney)
                    {
                        amount += room._totalPrice;
                    }
                }
                return amount * 10 ;
            }
            foreach (Room room in bookedRooms)
            {
                if (room._paidWithMoney)
                {
                    amount += (int)room._totalPrice;
                }
            }
            return amount;
        }
    }
}
