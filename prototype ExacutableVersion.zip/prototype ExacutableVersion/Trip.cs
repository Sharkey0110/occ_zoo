﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices.ComTypes;

namespace prototype
{
    internal class Trip
    {
        //SQL for trip table
        /// <summary>
        /// Saves trip details in database
        /// </summary>
        /// <param name="id">Id of user</param>
        /// <param name="type">Type of trip selected</param>
        /// <param name="totalPrice">The total price of the trip, duration, type and people going </param>
        /// <param name="startDate">The date the trip starts</param>
        /// <param name="endDate">The date the trip ends</param>
        /// <param name="duration">How long the trip is</param>
        /// <param name="people">How many people are going</param>
        ///<param name="paidWithMoney">If the trip was paid with money or with points</param>
        /// <param name="sqlConnection">The connection string</param>
        private void saveTrip(int id, string type, decimal totalPrice, DateTime startDate, DateTime endDate, int duration, int people, bool paidWithMoney, SqlConnection sqlConnection)
        {
            //connect to Database
            SqlCommand sqlCommand = new SqlCommand("BookTrip", sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            //Pass in Params
            sqlCommand.Parameters.AddWithValue("@User", id);
            sqlCommand.Parameters.AddWithValue("@Type", type);
            sqlCommand.Parameters.AddWithValue("@Price", totalPrice);
            sqlCommand.Parameters.AddWithValue("@StartDate", startDate);
            sqlCommand.Parameters.AddWithValue("@EndDate", endDate);
            sqlCommand.Parameters.AddWithValue("@Duration", duration);
            sqlCommand.Parameters.AddWithValue("@PaidWithMoney", paidWithMoney);
            sqlCommand.Parameters.AddWithValue("@People", people);

            //exucute
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        /// <summary>
        /// Updates the prices of the trip on the trip segment
        /// </summary>
        /// <param name="TripTypeBoxText">The type of trip</param>
        /// <param name="PeopleGoingText">The amount of people going</param>
        /// <param name="TripStartDate">Start date of trip</param>
        /// <param name="TripEndDate">End date of trip</param>
        /// <param name="TripMoneyPriceText">The label for price in money</param>
        /// <param name="TripPointPriceText">The label for price in points</param>
        /// <returns></returns>
        public (string, string) updateTripPrice(string TypeBoxText, string PeopleGoingText, DateTime StartDate, DateTime EndDate, string MoneyPriceText, string PointPriceText)
        //Update will run anytime any component on the trip section is changed, so the code needs to know which values have been changed
        {
            try
            {
                MoneyPriceText = "Money Price: ";
                PointPriceText = "Points Price: ";
                //price can only be calculated if a trip type is selected
                if (!string.IsNullOrEmpty(TypeBoxText))
                {
                    string type = TypeBoxText;
                    decimal price;
                    if (type == "Regular")
                    {
                        price = 5;
                    }
                    else if (type == "Deluxe")
                    {
                        price = 9;
                    }
                    else
                    {
                        price = 14;
                    }

                    //Specifiy variables
                    int peopleGoing;
                    int duration;

                    //Fill variables with default or selected values
                    if (string.IsNullOrEmpty(PeopleGoingText))
                    {
                        peopleGoing = 1;
                    }
                    else
                    {
                        peopleGoing = int.Parse(PeopleGoingText);
                    }

                    if (StartDate == null | EndDate == null | StartDate == EndDate)
                    {
                        duration = 1;
                    }
                    else
                    {
                        //Check if dates are impossible, enddate before startdate
                        if (StartDate > EndDate.AddDays(1))
                        {
                            MessageBox.Show("Ensure Start date is before end date");
                            return (MoneyPriceText, PointPriceText);
                        }
                        duration = (EndDate.Date - StartDate.Date).Days + 1;
                    }
                    {
                        //Calculate and display price
                        MoneyPriceText = "Money Price: " + (duration * price * peopleGoing).ToString("C", CultureInfo.CurrentCulture);
                        PointPriceText = "Points Price: " + (int)(duration * price * peopleGoing * 10);
                        return (MoneyPriceText, PointPriceText);
                    }
                }
                return (MoneyPriceText, PointPriceText);
            }
            catch
            {
                MessageBox.Show("People going must be a whole number");
                return (MoneyPriceText, PointPriceText);
            }
        }

        /// <summary>
        /// Collecting and error handling all of the trip data before sending it to the SQL database
        /// </summary>
        /// <param name="peopleGoingText">The amount of people going</param>
        /// <param name="tripStartDate">The startdate of the trip</param>
        /// <param name="tripEndDate">The enddate of the trip</param>
        /// <param name="type">The type of trip</param>
        /// <param name="payWithPoints">If the user is paying with points or not</param>
        /// <param name="rewardPoints">The amount</param>
        /// <param name="id"></param>
        /// <param name="sqlConnection"></param>
        public void bookTrip(string peopleGoingText, DateTime startDate, DateTime endDate, string type, bool payWithPoints, int id, SqlConnection sqlConnection)
        {
            //Identify variables
            int people = int.Parse(peopleGoingText);

            //check for valid dates
            if (startDate > endDate.AddDays(1) & startDate != endDate)
            {
                MessageBox.Show("Ensure Start date is before end date 3");
            }
            int tripDuration = (endDate.Date - startDate.Date).Days + 1;

            //temp
            decimal price;
            if (type == "Regular")
            {
                price = 5;
            }
            else if (type == "Deluxe")
            {
                price = 9;
            }
            else
            {
                price = 14;
            }

            decimal totalPrice = price * tripDuration * people;
            int totalPointPrice = (int)(price * tripDuration * people * 10);

            //check if user wants to pay in points, if they do set paidWithMoney to false

            if (payWithPoints)
            {
                saveTrip(id, type, totalPointPrice, startDate, endDate, tripDuration, people, false, sqlConnection);
            }
            else
            {
                saveTrip(id, type, totalPrice, startDate, endDate, tripDuration, people, true, sqlConnection);
            }
            MessageBox.Show("Trip booked sucessfully");
        }

        public decimal calculateMoneyOrPoints(string amountType, bool check, DateTime startDate, DateTime endDate, string peopleGoingText, string type)
        {
            if(!string.IsNullOrEmpty(type))
            {
                int people;
                try
                {
                    people = int.Parse(peopleGoingText);
                } catch
                {
                    people = 1;
                }


                //check for valid dates
                int tripDuration = (endDate.Date - startDate.Date).Days + 1;

                decimal price;
                if (type == "Regular")
                {
                    price = 5;
                }
                else if (type == "Deluxe")
                {
                    price = 9;
                }
                else
                {
                    price = 14;
                }

                if (amountType == "points")
                {
                    if (check)
                    {
                        decimal totalPrice = (price * tripDuration * people * 10);
                        return totalPrice;
                    }
                    return 0;
                }
                if (!check)
                {
                    decimal totalPrice = (price * tripDuration * people);
                    return totalPrice;
                }
                return 0;
            }
            return 0;
           
        }
    }
}
