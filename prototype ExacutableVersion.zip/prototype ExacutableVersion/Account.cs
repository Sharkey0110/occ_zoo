﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prototype
{
    internal class Account
    {
        public int _id { get; set; }
        public string _email { get; set; }
        public string _password { get; set; }
        public int _rewardPoints { get; set; }


        //SQL for users table
        /// <summary>
        /// Finds the logged in user and saves all of their edited data in database
        /// </summary>
        /// <param name="sqlConnection">The connection string</param>
        public void updateUser(SqlConnection sqlConnection)
        {
            //connect to Database
            SqlCommand sqlCommand = new SqlCommand("UpdateUser", sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            //Pass in params
            sqlCommand.Parameters.AddWithValue("@Id", _id);
            sqlCommand.Parameters.AddWithValue("@Email", _email);
            sqlCommand.Parameters.AddWithValue("@Password", _password);
            sqlCommand.Parameters.AddWithValue("@RewardPoints", _rewardPoints);

            //exucute
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        /// <summary>
        /// Lets a user already in the database access the logged in pannels
        /// </summary>
        /// <param name="email">Input from email text box</param>
        /// <param name="password">Input from password text box</param>
        /// <param name="sqlConnection">The connection srting</param>
        public void login(string email, string password, SqlConnection sqlConnection)
        {
            
            SqlCommand sqlCommand = new SqlCommand("Login", sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            //Pass in Params
            sqlCommand.Parameters.AddWithValue("@Email", email);
            sqlCommand.Parameters.AddWithValue("@Password", password);

            //exucute
            sqlConnection.Open();
            SqlDataReader reader = sqlCommand.ExecuteReader();
            //Pass data into user class
            while (reader.Read())
            {
                _id = (int)reader["Id"];
                _email = reader["Email"].ToString();
                _password = reader["Password"].ToString();
                _rewardPoints = (int)reader["Points"];
            }
            if(_id == 0)
            {
                MessageBox.Show("User not found");
            }
            sqlConnection.Close();
        }

        /// <summary>
        /// Lets a user pass in their data to the database
        /// </summary>
        /// <param name="email">Input from email text box</param>
        /// <param name="password">Input from password text box</param>
        /// <param name="sqlConnection">The connection srting</param>
        public void register(string email, string password, SqlConnection sqlConnection)
        {

            //connect to Database
            
            SqlCommand sqlCommand = new SqlCommand("Register", sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            //Pass in Params
            sqlCommand.Parameters.AddWithValue("@Email", email);
            sqlCommand.Parameters.AddWithValue("@Password", password);

            //exucute
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        //FUNCTIONS
        /// <summary>
        /// Checks for a logged in user and changes the app depending if user is logged in or not
        /// </summary>
        /// <param name="loggedInPannels">A list of pannels that should be shown if a user is logged in</param>
        /// <param name="loggedOutPannels">A list of pannels that should be shown if user is logged out</param>
        /// <param name="rewardsTextBox">A Rich text box that appears when user is logged in</param>
        public void checkForUser(List<GroupBox> loggedInPannels, List<GroupBox> loggedOutPannels, RichTextBox rewardsTextBox)
        //checks if a user is logged in and changes some of the pages depending on the result, if true show account specific options, if false show sign in forms
        {
            if (_id != 0)
            {
                loggedInPannels.ForEach(pannel => pannel.Visible = true);
                loggedOutPannels.ForEach(pannel => pannel.Visible = false);
                rewardsTextBox.Text = "You have " + _rewardPoints + " points";
            }
            else
            {
                loggedInPannels.ForEach(pannel => pannel.Visible = false);
                loggedOutPannels.ForEach(pannel => pannel.Visible = true);
            }
        }
    }
}
