﻿namespace prototype
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.BookNavBtn = new System.Windows.Forms.Button();
            this.AccountNavBtn = new System.Windows.Forms.Button();
            this.SettingsNavBtn = new System.Windows.Forms.Button();
            this.HomeNavBtn = new System.Windows.Forms.Button();
            this.AccountPage = new System.Windows.Forms.GroupBox();
            this.GreenAccountPannel = new System.Windows.Forms.Panel();
            this.LoginForm = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PasswordInput = new System.Windows.Forms.TextBox();
            this.EmailInput = new System.Windows.Forms.TextBox();
            this.RegisterBtn = new System.Windows.Forms.Button();
            this.LoginBtn = new System.Windows.Forms.Button();
            this.UserDetailsDisplay = new System.Windows.Forms.GroupBox();
            this.LogoutBtn = new System.Windows.Forms.Button();
            this.PurpleAccountPannel = new System.Windows.Forms.Panel();
            this.RewardPointDisplay = new System.Windows.Forms.GroupBox();
            this.PurpleRewardsTextBox = new System.Windows.Forms.RichTextBox();
            this.LoggedOutMessage = new System.Windows.Forms.GroupBox();
            this.PurpleAccountTextBox = new System.Windows.Forms.RichTextBox();
            this.HomePage = new System.Windows.Forms.GroupBox();
            this.PurpleHomePannel = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.PurpleHomeTextBox = new System.Windows.Forms.RichTextBox();
            this.GreenHomePannel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GreenHomeTextBox = new System.Windows.Forms.RichTextBox();
            this.BookPage = new System.Windows.Forms.GroupBox();
            this.TotalPointsSpent = new System.Windows.Forms.Label();
            this.TotalMoneySpent = new System.Windows.Forms.Label();
            this.PayBtn = new System.Windows.Forms.Button();
            this.PurpleBookPannel = new System.Windows.Forms.Panel();
            this.TotalRoomsPointPrice = new System.Windows.Forms.Label();
            this.TotalRoomsMoneyPrice = new System.Windows.Forms.Label();
            this.HotelActiveCheck = new System.Windows.Forms.CheckBox();
            this.RemoveRoomBtn = new System.Windows.Forms.Button();
            this.RoomPayPointsBtn = new System.Windows.Forms.Button();
            this.RoomPayMoneyBtn = new System.Windows.Forms.Button();
            this.BookedRoomsBox = new System.Windows.Forms.ComboBox();
            this.RoomPointsPrice = new System.Windows.Forms.Label();
            this.RoomMoneyPrice = new System.Windows.Forms.Label();
            this.AvailableRoomsBox = new System.Windows.Forms.ComboBox();
            this.RoomEndDate = new System.Windows.Forms.MonthCalendar();
            this.RoomStartDate = new System.Windows.Forms.MonthCalendar();
            this.label7 = new System.Windows.Forms.Label();
            this.GreenBookPannel = new System.Windows.Forms.Panel();
            this.TripActiveCheck = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.TripPointPriceText = new System.Windows.Forms.Label();
            this.TripMoneyPriceText = new System.Windows.Forms.Label();
            this.PeopleGoingText = new System.Windows.Forms.TextBox();
            this.TripPayWithpointsCheck = new System.Windows.Forms.CheckBox();
            this.TripTypeBox = new System.Windows.Forms.ComboBox();
            this.TripEndDate = new System.Windows.Forms.MonthCalendar();
            this.TripStartDate = new System.Windows.Forms.MonthCalendar();
            this.label6 = new System.Windows.Forms.Label();
            this.SettingPage = new System.Windows.Forms.GroupBox();
            this.PurpleSettingsPannel = new System.Windows.Forms.Panel();
            this.LoggedInSettingsDisplay = new System.Windows.Forms.GroupBox();
            this.DeleteAccountBtn = new System.Windows.Forms.Button();
            this.EditAccountBtn = new System.Windows.Forms.Button();
            this.GreenSettingPannel = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LargeTextBtn = new System.Windows.Forms.Button();
            this.DynamicColourBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.AccountPage.SuspendLayout();
            this.GreenAccountPannel.SuspendLayout();
            this.LoginForm.SuspendLayout();
            this.UserDetailsDisplay.SuspendLayout();
            this.PurpleAccountPannel.SuspendLayout();
            this.RewardPointDisplay.SuspendLayout();
            this.LoggedOutMessage.SuspendLayout();
            this.HomePage.SuspendLayout();
            this.PurpleHomePannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.GreenHomePannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.BookPage.SuspendLayout();
            this.PurpleBookPannel.SuspendLayout();
            this.GreenBookPannel.SuspendLayout();
            this.SettingPage.SuspendLayout();
            this.PurpleSettingsPannel.SuspendLayout();
            this.LoggedInSettingsDisplay.SuspendLayout();
            this.GreenSettingPannel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(211)))), ((int)(((byte)(48)))));
            this.panel1.Controls.Add(this.BookNavBtn);
            this.panel1.Controls.Add(this.AccountNavBtn);
            this.panel1.Controls.Add(this.SettingsNavBtn);
            this.panel1.Controls.Add(this.HomeNavBtn);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1321, 103);
            this.panel1.TabIndex = 0;
            // 
            // BookNavBtn
            // 
            this.BookNavBtn.Location = new System.Drawing.Point(379, 23);
            this.BookNavBtn.Name = "BookNavBtn";
            this.BookNavBtn.Size = new System.Drawing.Size(146, 57);
            this.BookNavBtn.TabIndex = 3;
            this.BookNavBtn.Text = "Book";
            this.BookNavBtn.UseVisualStyleBackColor = true;
            this.BookNavBtn.Click += new System.EventHandler(this.BookNavBtn_Click);
            // 
            // AccountNavBtn
            // 
            this.AccountNavBtn.Location = new System.Drawing.Point(777, 23);
            this.AccountNavBtn.Name = "AccountNavBtn";
            this.AccountNavBtn.Size = new System.Drawing.Size(146, 57);
            this.AccountNavBtn.TabIndex = 2;
            this.AccountNavBtn.Text = "Account";
            this.AccountNavBtn.UseVisualStyleBackColor = true;
            this.AccountNavBtn.Click += new System.EventHandler(this.AccountNavBtn_Click);
            // 
            // SettingsNavBtn
            // 
            this.SettingsNavBtn.Location = new System.Drawing.Point(1100, 23);
            this.SettingsNavBtn.Name = "SettingsNavBtn";
            this.SettingsNavBtn.Size = new System.Drawing.Size(146, 57);
            this.SettingsNavBtn.TabIndex = 1;
            this.SettingsNavBtn.Text = "Settings";
            this.SettingsNavBtn.UseVisualStyleBackColor = true;
            this.SettingsNavBtn.Click += new System.EventHandler(this.SettingsNavBtn_Click);
            // 
            // HomeNavBtn
            // 
            this.HomeNavBtn.Location = new System.Drawing.Point(61, 23);
            this.HomeNavBtn.Name = "HomeNavBtn";
            this.HomeNavBtn.Size = new System.Drawing.Size(146, 57);
            this.HomeNavBtn.TabIndex = 0;
            this.HomeNavBtn.Text = "Home";
            this.HomeNavBtn.UseVisualStyleBackColor = true;
            this.HomeNavBtn.Click += new System.EventHandler(this.HomeNavBtn_Click);
            // 
            // AccountPage
            // 
            this.AccountPage.Controls.Add(this.GreenAccountPannel);
            this.AccountPage.Controls.Add(this.PurpleAccountPannel);
            this.AccountPage.Location = new System.Drawing.Point(12, 109);
            this.AccountPage.Name = "AccountPage";
            this.AccountPage.Size = new System.Drawing.Size(1345, 679);
            this.AccountPage.TabIndex = 0;
            this.AccountPage.TabStop = false;
            this.AccountPage.Text = "account";
            this.AccountPage.Visible = false;
            // 
            // GreenAccountPannel
            // 
            this.GreenAccountPannel.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.GreenAccountPannel.Controls.Add(this.LoginForm);
            this.GreenAccountPannel.Controls.Add(this.UserDetailsDisplay);
            this.GreenAccountPannel.Location = new System.Drawing.Point(0, 300);
            this.GreenAccountPannel.Name = "GreenAccountPannel";
            this.GreenAccountPannel.Size = new System.Drawing.Size(1303, 355);
            this.GreenAccountPannel.TabIndex = 1;
            // 
            // LoginForm
            // 
            this.LoginForm.Controls.Add(this.label2);
            this.LoginForm.Controls.Add(this.label1);
            this.LoginForm.Controls.Add(this.PasswordInput);
            this.LoginForm.Controls.Add(this.EmailInput);
            this.LoginForm.Controls.Add(this.RegisterBtn);
            this.LoginForm.Controls.Add(this.LoginBtn);
            this.LoginForm.Location = new System.Drawing.Point(218, 0);
            this.LoginForm.Name = "LoginForm";
            this.LoginForm.Size = new System.Drawing.Size(792, 351);
            this.LoginForm.TabIndex = 0;
            this.LoginForm.TabStop = false;
            this.LoginForm.Text = "groupBox1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(349, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(362, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Email";
            // 
            // PasswordInput
            // 
            this.PasswordInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordInput.Location = new System.Drawing.Point(241, 183);
            this.PasswordInput.Name = "PasswordInput";
            this.PasswordInput.PasswordChar = '*';
            this.PasswordInput.Size = new System.Drawing.Size(297, 26);
            this.PasswordInput.TabIndex = 3;
            // 
            // EmailInput
            // 
            this.EmailInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailInput.Location = new System.Drawing.Point(241, 70);
            this.EmailInput.Name = "EmailInput";
            this.EmailInput.Size = new System.Drawing.Size(297, 26);
            this.EmailInput.TabIndex = 2;
            // 
            // RegisterBtn
            // 
            this.RegisterBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterBtn.Location = new System.Drawing.Point(583, 236);
            this.RegisterBtn.Name = "RegisterBtn";
            this.RegisterBtn.Size = new System.Drawing.Size(152, 40);
            this.RegisterBtn.TabIndex = 1;
            this.RegisterBtn.Text = "Register";
            this.RegisterBtn.UseVisualStyleBackColor = true;
            this.RegisterBtn.Click += new System.EventHandler(this.RegisterBtn_Click);
            // 
            // LoginBtn
            // 
            this.LoginBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginBtn.Location = new System.Drawing.Point(49, 236);
            this.LoginBtn.Name = "LoginBtn";
            this.LoginBtn.Size = new System.Drawing.Size(152, 40);
            this.LoginBtn.TabIndex = 0;
            this.LoginBtn.Text = "Login";
            this.LoginBtn.UseVisualStyleBackColor = true;
            this.LoginBtn.Click += new System.EventHandler(this.LoginBtn_Click);
            // 
            // UserDetailsDisplay
            // 
            this.UserDetailsDisplay.Controls.Add(this.LogoutBtn);
            this.UserDetailsDisplay.Location = new System.Drawing.Point(10, 22);
            this.UserDetailsDisplay.Name = "UserDetailsDisplay";
            this.UserDetailsDisplay.Size = new System.Drawing.Size(1273, 311);
            this.UserDetailsDisplay.TabIndex = 1;
            this.UserDetailsDisplay.TabStop = false;
            this.UserDetailsDisplay.Text = "groupBox1";
            this.UserDetailsDisplay.Visible = false;
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.Location = new System.Drawing.Point(1103, 147);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(148, 40);
            this.LogoutBtn.TabIndex = 0;
            this.LogoutBtn.Text = "Logout";
            this.LogoutBtn.UseVisualStyleBackColor = true;
            this.LogoutBtn.Click += new System.EventHandler(this.LogoutBtn_Click);
            // 
            // PurpleAccountPannel
            // 
            this.PurpleAccountPannel.BackColor = System.Drawing.Color.MidnightBlue;
            this.PurpleAccountPannel.Controls.Add(this.RewardPointDisplay);
            this.PurpleAccountPannel.Controls.Add(this.LoggedOutMessage);
            this.PurpleAccountPannel.Location = new System.Drawing.Point(0, 16);
            this.PurpleAccountPannel.Name = "PurpleAccountPannel";
            this.PurpleAccountPannel.Size = new System.Drawing.Size(1301, 286);
            this.PurpleAccountPannel.TabIndex = 0;
            // 
            // RewardPointDisplay
            // 
            this.RewardPointDisplay.Controls.Add(this.PurpleRewardsTextBox);
            this.RewardPointDisplay.Location = new System.Drawing.Point(34, 0);
            this.RewardPointDisplay.Name = "RewardPointDisplay";
            this.RewardPointDisplay.Size = new System.Drawing.Size(1219, 286);
            this.RewardPointDisplay.TabIndex = 1;
            this.RewardPointDisplay.TabStop = false;
            this.RewardPointDisplay.Text = "loggedIn";
            this.RewardPointDisplay.Visible = false;
            // 
            // PurpleRewardsTextBox
            // 
            this.PurpleRewardsTextBox.BackColor = System.Drawing.Color.MidnightBlue;
            this.PurpleRewardsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PurpleRewardsTextBox.ForeColor = System.Drawing.Color.White;
            this.PurpleRewardsTextBox.Location = new System.Drawing.Point(8, 57);
            this.PurpleRewardsTextBox.Name = "PurpleRewardsTextBox";
            this.PurpleRewardsTextBox.Size = new System.Drawing.Size(1074, 133);
            this.PurpleRewardsTextBox.TabIndex = 0;
            this.PurpleRewardsTextBox.Text = "You have XXXXXX points";
            // 
            // LoggedOutMessage
            // 
            this.LoggedOutMessage.Controls.Add(this.PurpleAccountTextBox);
            this.LoggedOutMessage.ForeColor = System.Drawing.Color.White;
            this.LoggedOutMessage.Location = new System.Drawing.Point(18, 14);
            this.LoggedOutMessage.Name = "LoggedOutMessage";
            this.LoggedOutMessage.Size = new System.Drawing.Size(1241, 253);
            this.LoggedOutMessage.TabIndex = 0;
            this.LoggedOutMessage.TabStop = false;
            this.LoggedOutMessage.Text = "loggedOut";
            // 
            // PurpleAccountTextBox
            // 
            this.PurpleAccountTextBox.BackColor = System.Drawing.Color.MidnightBlue;
            this.PurpleAccountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PurpleAccountTextBox.ForeColor = System.Drawing.Color.White;
            this.PurpleAccountTextBox.Location = new System.Drawing.Point(16, 19);
            this.PurpleAccountTextBox.Name = "PurpleAccountTextBox";
            this.PurpleAccountTextBox.ReadOnly = true;
            this.PurpleAccountTextBox.Size = new System.Drawing.Size(1000, 221);
            this.PurpleAccountTextBox.TabIndex = 0;
            this.PurpleAccountTextBox.Text = "Log in to see your reward points and book a new trip";
            // 
            // HomePage
            // 
            this.HomePage.Controls.Add(this.PurpleHomePannel);
            this.HomePage.Controls.Add(this.GreenHomePannel);
            this.HomePage.Location = new System.Drawing.Point(0, 109);
            this.HomePage.Name = "HomePage";
            this.HomePage.Size = new System.Drawing.Size(1320, 691);
            this.HomePage.TabIndex = 1;
            this.HomePage.TabStop = false;
            this.HomePage.Text = "home";
            // 
            // PurpleHomePannel
            // 
            this.PurpleHomePannel.BackColor = System.Drawing.Color.MidnightBlue;
            this.PurpleHomePannel.Controls.Add(this.pictureBox2);
            this.PurpleHomePannel.Controls.Add(this.PurpleHomeTextBox);
            this.PurpleHomePannel.Location = new System.Drawing.Point(5, 338);
            this.PurpleHomePannel.Name = "PurpleHomePannel";
            this.PurpleHomePannel.Size = new System.Drawing.Size(1309, 316);
            this.PurpleHomePannel.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::prototype.Properties.Resources.hotel;
            this.pictureBox2.Location = new System.Drawing.Point(853, 18);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(436, 276);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // PurpleHomeTextBox
            // 
            this.PurpleHomeTextBox.BackColor = System.Drawing.Color.MidnightBlue;
            this.PurpleHomeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PurpleHomeTextBox.ForeColor = System.Drawing.Color.White;
            this.PurpleHomeTextBox.Location = new System.Drawing.Point(17, 22);
            this.PurpleHomeTextBox.Name = "PurpleHomeTextBox";
            this.PurpleHomeTextBox.Size = new System.Drawing.Size(810, 267);
            this.PurpleHomeTextBox.TabIndex = 1;
            this.PurpleHomeTextBox.Text = "Feeling tired? Book a stay at our on-site hotel, so that you can keep these anima" +
    "ls company for as long as you like. Various types of rooms available";
            // 
            // GreenHomePannel
            // 
            this.GreenHomePannel.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.GreenHomePannel.Controls.Add(this.pictureBox1);
            this.GreenHomePannel.Controls.Add(this.GreenHomeTextBox);
            this.GreenHomePannel.Location = new System.Drawing.Point(7, 16);
            this.GreenHomePannel.Name = "GreenHomePannel";
            this.GreenHomePannel.Size = new System.Drawing.Size(1303, 326);
            this.GreenHomePannel.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::prototype.Properties.Resources.zoo;
            this.pictureBox1.Location = new System.Drawing.Point(17, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(545, 295);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // GreenHomeTextBox
            // 
            this.GreenHomeTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GreenHomeTextBox.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.GreenHomeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GreenHomeTextBox.Location = new System.Drawing.Point(595, 18);
            this.GreenHomeTextBox.Name = "GreenHomeTextBox";
            this.GreenHomeTextBox.ReadOnly = true;
            this.GreenHomeTextBox.Size = new System.Drawing.Size(670, 294);
            this.GreenHomeTextBox.TabIndex = 1;
            this.GreenHomeTextBox.Text = resources.GetString("GreenHomeTextBox.Text");
            // 
            // BookPage
            // 
            this.BookPage.Controls.Add(this.TotalPointsSpent);
            this.BookPage.Controls.Add(this.TotalMoneySpent);
            this.BookPage.Controls.Add(this.PayBtn);
            this.BookPage.Controls.Add(this.PurpleBookPannel);
            this.BookPage.Controls.Add(this.GreenBookPannel);
            this.BookPage.Location = new System.Drawing.Point(6, 109);
            this.BookPage.Name = "BookPage";
            this.BookPage.Size = new System.Drawing.Size(1336, 685);
            this.BookPage.TabIndex = 0;
            this.BookPage.TabStop = false;
            this.BookPage.Text = "book";
            this.BookPage.Visible = false;
            // 
            // TotalPointsSpent
            // 
            this.TotalPointsSpent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalPointsSpent.Location = new System.Drawing.Point(490, 569);
            this.TotalPointsSpent.Name = "TotalPointsSpent";
            this.TotalPointsSpent.Size = new System.Drawing.Size(311, 23);
            this.TotalPointsSpent.TabIndex = 6;
            this.TotalPointsSpent.Text = "Points spent:";
            this.TotalPointsSpent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TotalMoneySpent
            // 
            this.TotalMoneySpent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalMoneySpent.Location = new System.Drawing.Point(490, 536);
            this.TotalMoneySpent.Name = "TotalMoneySpent";
            this.TotalMoneySpent.Size = new System.Drawing.Size(311, 23);
            this.TotalMoneySpent.TabIndex = 5;
            this.TotalMoneySpent.Text = "Money spent:";
            this.TotalMoneySpent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PayBtn
            // 
            this.PayBtn.Location = new System.Drawing.Point(518, 609);
            this.PayBtn.Name = "PayBtn";
            this.PayBtn.Size = new System.Drawing.Size(253, 36);
            this.PayBtn.TabIndex = 2;
            this.PayBtn.Text = "Pay";
            this.PayBtn.UseVisualStyleBackColor = true;
            this.PayBtn.Click += new System.EventHandler(this.PayBtn_Click);
            // 
            // PurpleBookPannel
            // 
            this.PurpleBookPannel.BackColor = System.Drawing.Color.MidnightBlue;
            this.PurpleBookPannel.Controls.Add(this.TotalRoomsPointPrice);
            this.PurpleBookPannel.Controls.Add(this.TotalRoomsMoneyPrice);
            this.PurpleBookPannel.Controls.Add(this.HotelActiveCheck);
            this.PurpleBookPannel.Controls.Add(this.RemoveRoomBtn);
            this.PurpleBookPannel.Controls.Add(this.RoomPayPointsBtn);
            this.PurpleBookPannel.Controls.Add(this.RoomPayMoneyBtn);
            this.PurpleBookPannel.Controls.Add(this.BookedRoomsBox);
            this.PurpleBookPannel.Controls.Add(this.RoomPointsPrice);
            this.PurpleBookPannel.Controls.Add(this.RoomMoneyPrice);
            this.PurpleBookPannel.Controls.Add(this.AvailableRoomsBox);
            this.PurpleBookPannel.Controls.Add(this.RoomEndDate);
            this.PurpleBookPannel.Controls.Add(this.RoomStartDate);
            this.PurpleBookPannel.Controls.Add(this.label7);
            this.PurpleBookPannel.Location = new System.Drawing.Point(771, 21);
            this.PurpleBookPannel.Name = "PurpleBookPannel";
            this.PurpleBookPannel.Size = new System.Drawing.Size(498, 492);
            this.PurpleBookPannel.TabIndex = 1;
            // 
            // TotalRoomsPointPrice
            // 
            this.TotalRoomsPointPrice.AutoSize = true;
            this.TotalRoomsPointPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalRoomsPointPrice.ForeColor = System.Drawing.Color.White;
            this.TotalRoomsPointPrice.Location = new System.Drawing.Point(279, 449);
            this.TotalRoomsPointPrice.Name = "TotalRoomsPointPrice";
            this.TotalRoomsPointPrice.Size = new System.Drawing.Size(108, 20);
            this.TotalRoomsPointPrice.TabIndex = 14;
            this.TotalRoomsPointPrice.Text = "Points price: 0";
            // 
            // TotalRoomsMoneyPrice
            // 
            this.TotalRoomsMoneyPrice.AutoSize = true;
            this.TotalRoomsMoneyPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalRoomsMoneyPrice.ForeColor = System.Drawing.Color.White;
            this.TotalRoomsMoneyPrice.Location = new System.Drawing.Point(14, 449);
            this.TotalRoomsMoneyPrice.Name = "TotalRoomsMoneyPrice";
            this.TotalRoomsMoneyPrice.Size = new System.Drawing.Size(111, 20);
            this.TotalRoomsMoneyPrice.TabIndex = 13;
            this.TotalRoomsMoneyPrice.Text = "Money price: 0";
            // 
            // HotelActiveCheck
            // 
            this.HotelActiveCheck.AutoSize = true;
            this.HotelActiveCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HotelActiveCheck.ForeColor = System.Drawing.Color.White;
            this.HotelActiveCheck.Location = new System.Drawing.Point(314, 13);
            this.HotelActiveCheck.Name = "HotelActiveCheck";
            this.HotelActiveCheck.Size = new System.Drawing.Size(71, 24);
            this.HotelActiveCheck.TabIndex = 12;
            this.HotelActiveCheck.Text = "Active";
            this.HotelActiveCheck.UseVisualStyleBackColor = true;
            this.HotelActiveCheck.CheckedChanged += new System.EventHandler(this.HotelActiveCheck_CheckedChanged);
            // 
            // RemoveRoomBtn
            // 
            this.RemoveRoomBtn.Enabled = false;
            this.RemoveRoomBtn.Location = new System.Drawing.Point(332, 401);
            this.RemoveRoomBtn.Name = "RemoveRoomBtn";
            this.RemoveRoomBtn.Size = new System.Drawing.Size(140, 25);
            this.RemoveRoomBtn.TabIndex = 11;
            this.RemoveRoomBtn.Text = "Remove Room";
            this.RemoveRoomBtn.UseVisualStyleBackColor = true;
            this.RemoveRoomBtn.Click += new System.EventHandler(this.RemoveRoomBtn_Click);
            // 
            // RoomPayPointsBtn
            // 
            this.RoomPayPointsBtn.Enabled = false;
            this.RoomPayPointsBtn.Location = new System.Drawing.Point(358, 355);
            this.RoomPayPointsBtn.Name = "RoomPayPointsBtn";
            this.RoomPayPointsBtn.Size = new System.Drawing.Size(114, 26);
            this.RoomPayPointsBtn.TabIndex = 10;
            this.RoomPayPointsBtn.Text = "Pay Points";
            this.RoomPayPointsBtn.UseVisualStyleBackColor = true;
            this.RoomPayPointsBtn.Click += new System.EventHandler(this.RoomPayPointsBtn_Click);
            // 
            // RoomPayMoneyBtn
            // 
            this.RoomPayMoneyBtn.Enabled = false;
            this.RoomPayMoneyBtn.Location = new System.Drawing.Point(358, 322);
            this.RoomPayMoneyBtn.Name = "RoomPayMoneyBtn";
            this.RoomPayMoneyBtn.Size = new System.Drawing.Size(114, 27);
            this.RoomPayMoneyBtn.TabIndex = 9;
            this.RoomPayMoneyBtn.Text = "Pay Money";
            this.RoomPayMoneyBtn.UseVisualStyleBackColor = true;
            this.RoomPayMoneyBtn.Click += new System.EventHandler(this.RoomPayMoneyBtn_Click);
            // 
            // BookedRoomsBox
            // 
            this.BookedRoomsBox.Enabled = false;
            this.BookedRoomsBox.FormattingEnabled = true;
            this.BookedRoomsBox.Location = new System.Drawing.Point(18, 404);
            this.BookedRoomsBox.Name = "BookedRoomsBox";
            this.BookedRoomsBox.Size = new System.Drawing.Size(203, 21);
            this.BookedRoomsBox.TabIndex = 8;
            // 
            // RoomPointsPrice
            // 
            this.RoomPointsPrice.AutoSize = true;
            this.RoomPointsPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomPointsPrice.ForeColor = System.Drawing.Color.White;
            this.RoomPointsPrice.Location = new System.Drawing.Point(14, 355);
            this.RoomPointsPrice.Name = "RoomPointsPrice";
            this.RoomPointsPrice.Size = new System.Drawing.Size(137, 20);
            this.RoomPointsPrice.TabIndex = 7;
            this.RoomPointsPrice.Text = "Room points price";
            // 
            // RoomMoneyPrice
            // 
            this.RoomMoneyPrice.AutoSize = true;
            this.RoomMoneyPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomMoneyPrice.ForeColor = System.Drawing.Color.White;
            this.RoomMoneyPrice.Location = new System.Drawing.Point(14, 321);
            this.RoomMoneyPrice.Name = "RoomMoneyPrice";
            this.RoomMoneyPrice.Size = new System.Drawing.Size(141, 20);
            this.RoomMoneyPrice.TabIndex = 6;
            this.RoomMoneyPrice.Text = "Room money price";
            // 
            // AvailableRoomsBox
            // 
            this.AvailableRoomsBox.Enabled = false;
            this.AvailableRoomsBox.FormattingEnabled = true;
            this.AvailableRoomsBox.Location = new System.Drawing.Point(63, 274);
            this.AvailableRoomsBox.Name = "AvailableRoomsBox";
            this.AvailableRoomsBox.Size = new System.Drawing.Size(384, 21);
            this.AvailableRoomsBox.TabIndex = 4;
            this.AvailableRoomsBox.SelectedIndexChanged += new System.EventHandler(this.AvailableRoomsBox_SelectedIndexChanged);
            // 
            // RoomEndDate
            // 
            this.RoomEndDate.Enabled = false;
            this.RoomEndDate.Location = new System.Drawing.Point(263, 88);
            this.RoomEndDate.Name = "RoomEndDate";
            this.RoomEndDate.ShowToday = false;
            this.RoomEndDate.ShowTodayCircle = false;
            this.RoomEndDate.TabIndex = 2;
            this.RoomEndDate.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.RoomEndDate_DateChanged);
            // 
            // RoomStartDate
            // 
            this.RoomStartDate.Enabled = false;
            this.RoomStartDate.Location = new System.Drawing.Point(9, 88);
            this.RoomStartDate.MaxSelectionCount = 1;
            this.RoomStartDate.Name = "RoomStartDate";
            this.RoomStartDate.ShowToday = false;
            this.RoomStartDate.TabIndex = 3;
            this.RoomStartDate.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.RoomStartDate_DateChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(225, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 31);
            this.label7.TabIndex = 1;
            this.label7.Text = "Hotel";
            // 
            // GreenBookPannel
            // 
            this.GreenBookPannel.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.GreenBookPannel.Controls.Add(this.TripActiveCheck);
            this.GreenBookPannel.Controls.Add(this.label15);
            this.GreenBookPannel.Controls.Add(this.label14);
            this.GreenBookPannel.Controls.Add(this.TripPointPriceText);
            this.GreenBookPannel.Controls.Add(this.TripMoneyPriceText);
            this.GreenBookPannel.Controls.Add(this.PeopleGoingText);
            this.GreenBookPannel.Controls.Add(this.TripPayWithpointsCheck);
            this.GreenBookPannel.Controls.Add(this.TripTypeBox);
            this.GreenBookPannel.Controls.Add(this.TripEndDate);
            this.GreenBookPannel.Controls.Add(this.TripStartDate);
            this.GreenBookPannel.Controls.Add(this.label6);
            this.GreenBookPannel.Location = new System.Drawing.Point(21, 21);
            this.GreenBookPannel.Name = "GreenBookPannel";
            this.GreenBookPannel.Size = new System.Drawing.Size(498, 492);
            this.GreenBookPannel.TabIndex = 0;
            // 
            // TripActiveCheck
            // 
            this.TripActiveCheck.AutoSize = true;
            this.TripActiveCheck.Checked = true;
            this.TripActiveCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TripActiveCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TripActiveCheck.Location = new System.Drawing.Point(318, 16);
            this.TripActiveCheck.Name = "TripActiveCheck";
            this.TripActiveCheck.Size = new System.Drawing.Size(71, 24);
            this.TripActiveCheck.TabIndex = 9;
            this.TripActiveCheck.Text = "Active";
            this.TripActiveCheck.UseVisualStyleBackColor = true;
            this.TripActiveCheck.CheckedChanged += new System.EventHandler(this.TripActiveCheck_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(41, 355);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(105, 20);
            this.label15.TabIndex = 8;
            this.label15.Text = "People Going";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(41, 301);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 20);
            this.label14.TabIndex = 7;
            this.label14.Text = "Trip Type";
            // 
            // TripPointPriceText
            // 
            this.TripPointPriceText.AutoSize = true;
            this.TripPointPriceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TripPointPriceText.Location = new System.Drawing.Point(7, 465);
            this.TripPointPriceText.Name = "TripPointPriceText";
            this.TripPointPriceText.Size = new System.Drawing.Size(95, 20);
            this.TripPointPriceText.TabIndex = 6;
            this.TripPointPriceText.Text = "Points price:";
            // 
            // TripMoneyPriceText
            // 
            this.TripMoneyPriceText.AutoSize = true;
            this.TripMoneyPriceText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TripMoneyPriceText.Location = new System.Drawing.Point(7, 435);
            this.TripMoneyPriceText.Name = "TripMoneyPriceText";
            this.TripMoneyPriceText.Size = new System.Drawing.Size(99, 20);
            this.TripMoneyPriceText.TabIndex = 5;
            this.TripMoneyPriceText.Text = "Money Price:";
            // 
            // PeopleGoingText
            // 
            this.PeopleGoingText.Location = new System.Drawing.Point(235, 355);
            this.PeopleGoingText.Name = "PeopleGoingText";
            this.PeopleGoingText.Size = new System.Drawing.Size(169, 20);
            this.PeopleGoingText.TabIndex = 4;
            this.PeopleGoingText.TextChanged += new System.EventHandler(this.PeopleGoingText_TextChanged);
            // 
            // TripPayWithpointsCheck
            // 
            this.TripPayWithpointsCheck.AutoSize = true;
            this.TripPayWithpointsCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TripPayWithpointsCheck.Location = new System.Drawing.Point(366, 445);
            this.TripPayWithpointsCheck.Name = "TripPayWithpointsCheck";
            this.TripPayWithpointsCheck.Size = new System.Drawing.Size(133, 24);
            this.TripPayWithpointsCheck.TabIndex = 3;
            this.TripPayWithpointsCheck.Text = "Pay with points";
            this.TripPayWithpointsCheck.UseVisualStyleBackColor = true;
            this.TripPayWithpointsCheck.CheckedChanged += new System.EventHandler(this.TripPayWithpointsCheck_CheckedChanged);
            // 
            // TripTypeBox
            // 
            this.TripTypeBox.FormattingEnabled = true;
            this.TripTypeBox.Items.AddRange(new object[] {
            "Regular",
            "Deluxe",
            "Educational"});
            this.TripTypeBox.Location = new System.Drawing.Point(235, 300);
            this.TripTypeBox.Name = "TripTypeBox";
            this.TripTypeBox.Size = new System.Drawing.Size(169, 21);
            this.TripTypeBox.TabIndex = 3;
            this.TripTypeBox.SelectedIndexChanged += new System.EventHandler(this.TripTypeBox_SelectedIndexChanged);
            // 
            // TripEndDate
            // 
            this.TripEndDate.Location = new System.Drawing.Point(262, 87);
            this.TripEndDate.MaxSelectionCount = 1;
            this.TripEndDate.Name = "TripEndDate";
            this.TripEndDate.ShowToday = false;
            this.TripEndDate.ShowTodayCircle = false;
            this.TripEndDate.TabIndex = 2;
            this.TripEndDate.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.TripEndDate_DateChanged);
            // 
            // TripStartDate
            // 
            this.TripStartDate.Location = new System.Drawing.Point(9, 87);
            this.TripStartDate.Name = "TripStartDate";
            this.TripStartDate.ShowToday = false;
            this.TripStartDate.TabIndex = 1;
            this.TripStartDate.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.TripStartDate_DateChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(221, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 31);
            this.label6.TabIndex = 0;
            this.label6.Text = "Zoo";
            // 
            // SettingPage
            // 
            this.SettingPage.Controls.Add(this.PurpleSettingsPannel);
            this.SettingPage.Controls.Add(this.GreenSettingPannel);
            this.SettingPage.Location = new System.Drawing.Point(18, 109);
            this.SettingPage.Name = "SettingPage";
            this.SettingPage.Size = new System.Drawing.Size(1373, 673);
            this.SettingPage.TabIndex = 0;
            this.SettingPage.TabStop = false;
            this.SettingPage.Text = "settings";
            this.SettingPage.Visible = false;
            // 
            // PurpleSettingsPannel
            // 
            this.PurpleSettingsPannel.BackColor = System.Drawing.Color.MidnightBlue;
            this.PurpleSettingsPannel.Controls.Add(this.LoggedInSettingsDisplay);
            this.PurpleSettingsPannel.Location = new System.Drawing.Point(647, 16);
            this.PurpleSettingsPannel.Name = "PurpleSettingsPannel";
            this.PurpleSettingsPannel.Size = new System.Drawing.Size(649, 640);
            this.PurpleSettingsPannel.TabIndex = 1;
            // 
            // LoggedInSettingsDisplay
            // 
            this.LoggedInSettingsDisplay.Controls.Add(this.DeleteAccountBtn);
            this.LoggedInSettingsDisplay.Controls.Add(this.EditAccountBtn);
            this.LoggedInSettingsDisplay.Location = new System.Drawing.Point(26, 8);
            this.LoggedInSettingsDisplay.Name = "LoggedInSettingsDisplay";
            this.LoggedInSettingsDisplay.Size = new System.Drawing.Size(598, 602);
            this.LoggedInSettingsDisplay.TabIndex = 0;
            this.LoggedInSettingsDisplay.TabStop = false;
            this.LoggedInSettingsDisplay.Text = "groupBox1";
            this.LoggedInSettingsDisplay.Visible = false;
            // 
            // DeleteAccountBtn
            // 
            this.DeleteAccountBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteAccountBtn.Location = new System.Drawing.Point(226, 383);
            this.DeleteAccountBtn.Name = "DeleteAccountBtn";
            this.DeleteAccountBtn.Size = new System.Drawing.Size(177, 53);
            this.DeleteAccountBtn.TabIndex = 1;
            this.DeleteAccountBtn.Text = "Delete Account";
            this.DeleteAccountBtn.UseVisualStyleBackColor = true;
            this.DeleteAccountBtn.Click += new System.EventHandler(this.DeleteAccountBtn_Click);
            // 
            // EditAccountBtn
            // 
            this.EditAccountBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditAccountBtn.Location = new System.Drawing.Point(226, 141);
            this.EditAccountBtn.Name = "EditAccountBtn";
            this.EditAccountBtn.Size = new System.Drawing.Size(177, 53);
            this.EditAccountBtn.TabIndex = 0;
            this.EditAccountBtn.Text = "Edit Account";
            this.EditAccountBtn.UseVisualStyleBackColor = true;
            this.EditAccountBtn.Click += new System.EventHandler(this.EditAccountBtn_Click);
            // 
            // GreenSettingPannel
            // 
            this.GreenSettingPannel.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.GreenSettingPannel.Controls.Add(this.label5);
            this.GreenSettingPannel.Controls.Add(this.label4);
            this.GreenSettingPannel.Controls.Add(this.label3);
            this.GreenSettingPannel.Controls.Add(this.LargeTextBtn);
            this.GreenSettingPannel.Controls.Add(this.DynamicColourBtn);
            this.GreenSettingPannel.Location = new System.Drawing.Point(4, 16);
            this.GreenSettingPannel.Name = "GreenSettingPannel";
            this.GreenSettingPannel.Size = new System.Drawing.Size(645, 640);
            this.GreenSettingPannel.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(180, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(248, 33);
            this.label5.TabIndex = 5;
            this.label5.Text = "General Settings";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(97, 397);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 31);
            this.label4.TabIndex = 4;
            this.label4.Text = "Large text";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(54, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(236, 31);
            this.label3.TabIndex = 3;
            this.label3.Text = "Dynamic Colours";
            // 
            // LargeTextBtn
            // 
            this.LargeTextBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LargeTextBtn.Location = new System.Drawing.Point(371, 391);
            this.LargeTextBtn.Name = "LargeTextBtn";
            this.LargeTextBtn.Size = new System.Drawing.Size(177, 53);
            this.LargeTextBtn.TabIndex = 2;
            this.LargeTextBtn.Text = "Off";
            this.LargeTextBtn.UseVisualStyleBackColor = true;
            this.LargeTextBtn.Click += new System.EventHandler(this.LargeTextBtn_Click);
            // 
            // DynamicColourBtn
            // 
            this.DynamicColourBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DynamicColourBtn.Location = new System.Drawing.Point(371, 149);
            this.DynamicColourBtn.Name = "DynamicColourBtn";
            this.DynamicColourBtn.Size = new System.Drawing.Size(177, 53);
            this.DynamicColourBtn.TabIndex = 1;
            this.DynamicColourBtn.Text = "On";
            this.DynamicColourBtn.UseVisualStyleBackColor = true;
            this.DynamicColourBtn.Click += new System.EventHandler(this.DynamicColourBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1313, 758);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.AccountPage);
            this.Controls.Add(this.BookPage);
            this.Controls.Add(this.HomePage);
            this.Controls.Add(this.SettingPage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.AccountPage.ResumeLayout(false);
            this.GreenAccountPannel.ResumeLayout(false);
            this.LoginForm.ResumeLayout(false);
            this.LoginForm.PerformLayout();
            this.UserDetailsDisplay.ResumeLayout(false);
            this.PurpleAccountPannel.ResumeLayout(false);
            this.RewardPointDisplay.ResumeLayout(false);
            this.LoggedOutMessage.ResumeLayout(false);
            this.HomePage.ResumeLayout(false);
            this.PurpleHomePannel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.GreenHomePannel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.BookPage.ResumeLayout(false);
            this.PurpleBookPannel.ResumeLayout(false);
            this.PurpleBookPannel.PerformLayout();
            this.GreenBookPannel.ResumeLayout(false);
            this.GreenBookPannel.PerformLayout();
            this.SettingPage.ResumeLayout(false);
            this.PurpleSettingsPannel.ResumeLayout(false);
            this.LoggedInSettingsDisplay.ResumeLayout(false);
            this.GreenSettingPannel.ResumeLayout(false);
            this.GreenSettingPannel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BookNavBtn;
        private System.Windows.Forms.Button AccountNavBtn;
        private System.Windows.Forms.Button SettingsNavBtn;
        private System.Windows.Forms.Button HomeNavBtn;
        private System.Windows.Forms.GroupBox HomePage;
        private System.Windows.Forms.GroupBox BookPage;
        private System.Windows.Forms.GroupBox AccountPage;
        private System.Windows.Forms.GroupBox SettingPage;
        private System.Windows.Forms.Panel GreenAccountPannel;
        private System.Windows.Forms.Panel PurpleAccountPannel;
        private System.Windows.Forms.Panel PurpleBookPannel;
        private System.Windows.Forms.Panel GreenBookPannel;
        private System.Windows.Forms.Panel PurpleSettingsPannel;
        private System.Windows.Forms.Panel GreenSettingPannel;
        private System.Windows.Forms.Panel PurpleHomePannel;
        private System.Windows.Forms.Panel GreenHomePannel;
        private System.Windows.Forms.RichTextBox PurpleHomeTextBox;
        private System.Windows.Forms.RichTextBox GreenHomeTextBox;
        private System.Windows.Forms.GroupBox LoggedOutMessage;
        private System.Windows.Forms.RichTextBox PurpleAccountTextBox;
        private System.Windows.Forms.GroupBox LoginForm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PasswordInput;
        private System.Windows.Forms.TextBox EmailInput;
        private System.Windows.Forms.Button RegisterBtn;
        private System.Windows.Forms.Button LoginBtn;
        private System.Windows.Forms.GroupBox RewardPointDisplay;
        private System.Windows.Forms.RichTextBox PurpleRewardsTextBox;
        private System.Windows.Forms.GroupBox UserDetailsDisplay;
        private System.Windows.Forms.Button LogoutBtn;
        private System.Windows.Forms.GroupBox LoggedInSettingsDisplay;
        private System.Windows.Forms.Button DeleteAccountBtn;
        private System.Windows.Forms.Button EditAccountBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button LargeTextBtn;
        private System.Windows.Forms.Button DynamicColourBtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MonthCalendar TripStartDate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label TotalPointsSpent;
        private System.Windows.Forms.Label TotalMoneySpent;
        private System.Windows.Forms.CheckBox TripPayWithpointsCheck;
        private System.Windows.Forms.Button PayBtn;
        private System.Windows.Forms.MonthCalendar RoomEndDate;
        private System.Windows.Forms.MonthCalendar RoomStartDate;
        private System.Windows.Forms.TextBox PeopleGoingText;
        private System.Windows.Forms.ComboBox TripTypeBox;
        private System.Windows.Forms.MonthCalendar TripEndDate;
        private System.Windows.Forms.Label TripPointPriceText;
        private System.Windows.Forms.Label TripMoneyPriceText;
        private System.Windows.Forms.Button RoomPayPointsBtn;
        private System.Windows.Forms.Button RoomPayMoneyBtn;
        private System.Windows.Forms.ComboBox BookedRoomsBox;
        private System.Windows.Forms.Label RoomPointsPrice;
        private System.Windows.Forms.Label RoomMoneyPrice;
        private System.Windows.Forms.ComboBox AvailableRoomsBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox TripActiveCheck;
        private System.Windows.Forms.Button RemoveRoomBtn;
        private System.Windows.Forms.CheckBox HotelActiveCheck;
        private System.Windows.Forms.Label TotalRoomsPointPrice;
        private System.Windows.Forms.Label TotalRoomsMoneyPrice;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

