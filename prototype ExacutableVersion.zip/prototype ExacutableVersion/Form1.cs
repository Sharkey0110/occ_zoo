﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prototype
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //GLOBAL VARIABLES
        private Account User = new Account();
        private Trip Trip = new Trip();
        private Room Room = new Room();

        //On load the comboboxes should be filled
        private void Form1_Load(object sender, EventArgs e)
        {
            TripStartDate.MinDate = DateTime.Now;
            RoomStartDate.MinDate = DateTime.Now;
            updateAvailableRooms();
        }

        /// <summary>
        /// Reloads the available rooms and booked rooms comboboxes so user cant select the same room multiple times
        /// </summary>
        private void updateAvailableRooms()
        {
            //clear existing data
            AvailableRoomsBox.Items.Clear();
            BookedRoomsBox.Items.Clear();
            //get all rooms
            SqlConnection sqlConnection = sqlConnect();
            List<Room> rooms = Room.getRooms(sqlConnection);

            //check if rooms are in the global booked rooms list
            foreach (Room room in rooms)
            {
                bool addToAvailable = true;
                foreach (Room bookedRoom in Room.bookedRooms)
                {
                    //if they are in the booked room list, put them in the booked rooms combobox, and display money or point price depending on how it was purchased
                    if (room._roomId == bookedRoom._roomId)
                    {
                        addToAvailable = false;
                        string price;
                        if (bookedRoom._paidWithMoney)
                        {
                            price = "  £" + bookedRoom._totalPrice;
                        } else
                        {
                            price = "   " + (int)bookedRoom._totalPrice * 10 + " Points";
                        }
                        BookedRoomsBox.Items.Add("Room " + room._roomId + " - " + room._roomType + price);
                    }
                }
                //if they are not add to available room list
                if (addToAvailable)
                {
                    AvailableRoomsBox.Items.Add("Room " + room._roomId + " - " + room._roomType + "   £" + room._dayPrice);
                }
            }
        }

        //BUTTON NAVIGATION
        /// <summary>
        /// makes all pages invisable, then makes selected page visable for user to see
        /// </summary>
        /// <param name="page">The page the user wants to switch to</param>
        private void changePage(GroupBox page)
        {
            //loop though all group boxes and deactivate them
            List<GroupBox> pages = new List<GroupBox>{ HomePage, BookPage, AccountPage, SettingPage};
            foreach (GroupBox p in pages)
            {
                p.Visible = false;
            };
            //activate specified page
            page.Visible = true;

        }

        private void HomeNavBtn_Click(object sender, EventArgs e)
        {
            changePage(HomePage);
        }

        private void BookNavBtn_Click(object sender, EventArgs e)
        {
            //only allows users to view booking page if they are logged in
            if (User._id != 0)
            {
                changePage(BookPage);
            }
            else
            {
                changePage(AccountPage);
            }
        }

        private void AccountNavBtn_Click(object sender, EventArgs e)
        {
            changePage(AccountPage);
            //gather all of the components that change depending on user status
            (List<GroupBox>, List<GroupBox>, RichTextBox) loggedInOutPannels = getLoggedInOutPannels();

            User.checkForUser(loggedInOutPannels.Item1, loggedInOutPannels.Item2, loggedInOutPannels.Item3);
        }


        private void SettingsNavBtn_Click(object sender, EventArgs e)
        {
            changePage(SettingPage);
        }


        //Only declaration of sql string, making it easy to alter
        private SqlConnection sqlConnect()
        {
            //Creates the connection to the database and returns it
            string connectionString = "" +
                "Data Source = (LocalDB)\\MSSQLLOCALDB;" +
                "AttachDbFilename = |DataDirectory|\\database.mdf;" +
                "Integrated Security = True;" +
                "Connect Timeout = 30";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            return sqlConnection;
        }


        //BOOK PAGE BUTTONS

        //UTILS

        /// <summary>
        /// updates the trip section price or the hotel section price and the total price
        /// </summary>
        /// <param name="type">Tells the code which local segment price to update</param>
        private void updateSection(string type)
        {
            if(type == "trip")
            {
                (string, string) tripPrices = Trip.updateTripPrice(TripTypeBox.Text, PeopleGoingText.Text, TripStartDate.SelectionStart, TripEndDate.SelectionStart, TripMoneyPriceText.Text, TripPointPriceText.Text);
                TripMoneyPriceText.Text = tripPrices.Item1;
                TripPointPriceText.Text = tripPrices.Item2;
            }
            else
            {
                SqlConnection sqlConnection = sqlConnect();
                (string, string) roomPrices = Room.updateRoomPrice(AvailableRoomsBox.Text, RoomStartDate.SelectionStart, RoomEndDate.SelectionStart, RoomMoneyPrice.Text, RoomPointsPrice.Text, sqlConnection);
                RoomMoneyPrice.Text = roomPrices.Item1;
                RoomPointsPrice.Text = roomPrices.Item2;
            }

            if((!string.IsNullOrEmpty(TripTypeBox.Text) & type == "trip") | type == "hotel" )
            {
                int pointsNeeded = (int)Room.calculateMoneyOrPoints("points") + (int)Trip.calculateMoneyOrPoints("points", TripPayWithpointsCheck.Checked, TripStartDate.SelectionStart, TripEndDate.SelectionStart, PeopleGoingText.Text, TripTypeBox.Text);
                decimal cost = Room.calculateMoneyOrPoints("money") + Trip.calculateMoneyOrPoints("money", TripPayWithpointsCheck.Checked, TripStartDate.SelectionStart, TripEndDate.SelectionStart, PeopleGoingText.Text, TripTypeBox.Text);
                TotalMoneySpent.Text = "Money spent: " + cost.ToString("C", CultureInfo.CurrentCulture);
                TotalPointsSpent.Text = "Points spent: " + pointsNeeded;
            }
        }

        /// <summary>
        /// Calls the functions to update the price on the hotel segment as well as updating the comboboxes, then resets the text in the comboboxes for extra security
        /// </summary>
        private void cleanHotelSection()
        {
            updateAvailableRooms();
            updateSection("hotel");
            AvailableRoomsBox.ResetText();
            BookedRoomsBox.ResetText();
        }

        //Trip Section event handlers
        private void TripActiveCheck_CheckedChanged(object sender, EventArgs e)
        {
            bool active = TripActiveCheck.Checked;
            if (active)
            {
                TripStartDate.Enabled = true;
                TripEndDate.Enabled = true;
                PeopleGoingText.Enabled = true;
                TripTypeBox.Enabled = true;
                TripPayWithpointsCheck.Enabled = true;
            }
            else
            {
                TripStartDate.Enabled = false;
                TripEndDate.Enabled = false;
                PeopleGoingText.Enabled = false;
                TripTypeBox.Enabled = false;
                TripPayWithpointsCheck.Enabled = false;
            }
        }

        private void TripTypeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            updateSection("trip");
        }

        private void TripStartDate_DateChanged(object sender, DateRangeEventArgs e)
        {
            updateSection("trip");
        }

        private void TripEndDate_DateChanged(object sender, DateRangeEventArgs e)
        {
            updateSection("trip");
        }

        private void PeopleGoingText_TextChanged(object sender, EventArgs e)
        {
            updateSection("trip");
        }

        private void TripPayWithpointsCheck_CheckedChanged(object sender, EventArgs e)
        {
            updateSection("trip");
        }

        //Hotel Section event handlers
        private void HotelActiveCheck_CheckedChanged(object sender, EventArgs e)
        {
            bool active = HotelActiveCheck.Checked;
            if (active)
            {
                RoomStartDate.Enabled = true;
                RoomEndDate.Enabled = true;
                AvailableRoomsBox.Enabled = true;
                RoomPayMoneyBtn.Enabled = true;
                RoomPayPointsBtn.Enabled = true;
                RemoveRoomBtn.Enabled = true;
                RemoveRoomBtn.Enabled = true;
                BookedRoomsBox.Enabled = true;
            }
            else
            {
                RoomStartDate.Enabled = false;
                RoomEndDate.Enabled = false;
                AvailableRoomsBox.Enabled = false;
                RoomPayMoneyBtn.Enabled = false;
                RoomPayPointsBtn.Enabled = false;
                RemoveRoomBtn.Enabled = false;
                RemoveRoomBtn.Enabled = false;
                BookedRoomsBox.Enabled = false;
            }
        }

        private void AvailableRoomsBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            updateSection("hotel");
        }

        private void RoomStartDate_DateChanged(object sender, DateRangeEventArgs e)
        {
            updateSection("hotel");
        }

        private void RoomEndDate_DateChanged(object sender, DateRangeEventArgs e)
        {
            updateSection("hotel");
        }


        private void RoomPayMoneyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlConnection = sqlConnect();
                //adds the room to the booked room list with a true value for the paidWithMoney variable
                Room.addRoomToList(RoomStartDate.SelectionStart, RoomEndDate.SelectionStart, AvailableRoomsBox.Text, User._id, true, sqlConnection);
                cleanHotelSection();
            } catch
            {
                MessageBox.Show("Add all details first");
            }
            
        }

        private void RoomPayPointsBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlConnection = sqlConnect();
                //adds the room to the booked room list with a false value for the paidWithMoney variable
                Room.addRoomToList(RoomStartDate.SelectionStart, RoomEndDate.SelectionStart, AvailableRoomsBox.Text, User._id, false, sqlConnection);
                cleanHotelSection();
            }
            catch
            {
                MessageBox.Show("Add all details first");
            }
        }

        private void RemoveRoomBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //get the room number which is the value after the text that says "Room"
                int roomNum = int.Parse(BookedRoomsBox.Text.Split(' ')[1]);
                Room.removeRoomFromList(roomNum);
                cleanHotelSection();
            }
            catch
            {
                MessageBox.Show("Please select a room first");
            }
        }


        private void PayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //checks how many points the whole trip will cost
                int pointsNeeded = (int)Room.calculateMoneyOrPoints("points") + (int)Trip.calculateMoneyOrPoints("points", TripPayWithpointsCheck.Checked, TripStartDate.SelectionStart, TripEndDate.SelectionStart, PeopleGoingText.Text, TripTypeBox.Text);
                decimal cost = Room.calculateMoneyOrPoints("money") + Trip.calculateMoneyOrPoints("money", TripPayWithpointsCheck.Checked, TripStartDate.SelectionStart, TripEndDate.SelectionStart, PeopleGoingText.Text, TripTypeBox.Text);

                //only allows trip to be booked if user has enough points
                if (pointsNeeded <= User._rewardPoints)
                {
                    if (TripStartDate.SelectionStart > TripEndDate.SelectionStart.AddDays(1))
                    {
                        MessageBox.Show("Trip start date is before trip end date");
                    }
                    else
                    {
                        SqlConnection sqlConnection = sqlConnect();
                        //book the zoo section if the user toggled it
                        if (TripActiveCheck.Checked)
                        {
                            Trip.bookTrip(PeopleGoingText.Text, TripStartDate.SelectionStart, TripEndDate.SelectionStart, TripTypeBox.Text, TripPayWithpointsCheck.Checked, User._id, sqlConnection);
                            //Cleanup after submition
                            PeopleGoingText.Clear();
                            TripStartDate.ResetText();
                            TripEndDate.ResetText();
                            TripTypeBox.ResetText();
                        }
                        //book the hotel section if the user toggled it
                        if (HotelActiveCheck.Checked)
                        {
                            //SQL
                            Room.bookRooms(sqlConnection);

                            //Cleanup
                            AvailableRoomsBox.ResetText();
                            BookedRoomsBox.ResetText();
                        }

                        //update the users reward points
                        User._rewardPoints += ((int)cost - pointsNeeded);
                        User.updateUser(sqlConnection);
                    }
                }
                else
                {
                    MessageBox.Show("Not enough points");
                }
            } catch
            {
                MessageBox.Show("please fill out all data");
            }
        }


        //ACCOUNT PAGE FUNCTIONS

        /// <summary>
        /// A function that collects all of the pannels that change depending on the status of the user, which saves creating a global variable
        /// </summary>
        /// <returns>3 items, a list of the logged in pannels, a list of the logged out pannels and the textbox that displays the users reward points</returns>
        private (List<GroupBox>, List<GroupBox>, RichTextBox) getLoggedInOutPannels()
        {
            List<GroupBox> loggedInPannels = new List<GroupBox> { RewardPointDisplay, UserDetailsDisplay, LoggedInSettingsDisplay };
            List<GroupBox> loggedOutPannels = new List<GroupBox> { LoggedOutMessage, LoginForm };
            RichTextBox rewardsTextBox = PurpleRewardsTextBox;
            return (loggedInPannels, loggedOutPannels, rewardsTextBox);
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //get user dependant pannels
                (List<GroupBox>, List<GroupBox>, RichTextBox) loggedInOutPannels = getLoggedInOutPannels();
                string email = EmailInput.Text;
                string password = PasswordInput.Text;
                SqlConnection sqlConnection = sqlConnect();

                //collect user data from database
                User.login(email, password, sqlConnection);

                //reset the page so that user dependant pannels can change accordantly 
                User.checkForUser(loggedInOutPannels.Item1, loggedInOutPannels.Item2, loggedInOutPannels.Item3);
            } catch
            {
                MessageBox.Show("Login Invalid");
            }
        }


        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            //get user dependant pannels
            (List<GroupBox>, List<GroupBox>, RichTextBox) loggedInOutPannels = getLoggedInOutPannels();

            //wipe user data on the local app
            User._id = 0;
            User._email = null;
            User._rewardPoints = 0;

            //reset page
            User.checkForUser(loggedInOutPannels.Item1, loggedInOutPannels.Item2, loggedInOutPannels.Item3);
        }


        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //Get user dependant pannels
                (List<GroupBox>, List<GroupBox>, RichTextBox) loggedInOutPannels = getLoggedInOutPannels();
                string email = EmailInput.Text;
                string password = PasswordInput.Text;
                if(string.IsNullOrEmpty(email) | string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Fill out all fields");
                }
                else if(email.Length > 64 | password.Length > 64)
                {
                    MessageBox.Show("Email or password too long");
                }
                else
                {
                    SqlConnection sqlConnection = sqlConnect();

                    //register login and update the page
                    User.register(email, password, sqlConnection);
                    User.login(email, password, sqlConnection);
                    User.checkForUser(loggedInOutPannels.Item1, loggedInOutPannels.Item2, loggedInOutPannels.Item3);
                }
            }
            catch
            {
                MessageBox.Show("Something went wrong with registering");
            }
        }


        //SETTING PAGE FUNCTIONS

        /// <summary>
        /// Changes the colours of the app from vibrent to monochrome and vise versa
        /// </summary>
        /// <param name="dynamicColours">Pass true for vibrent, false for monochrome</param>
        private void changeColours(bool dynamicColours)
        {
            List<Panel> greenPanels = new List<Panel> { GreenSettingPannel, GreenAccountPannel, GreenBookPannel, GreenHomePannel };
            List<Panel> purplePannels = new List<Panel> { PurpleSettingsPannel, PurpleAccountPannel, PurpleBookPannel, PurpleHomePannel };
            List<RichTextBox> purpleTextBoxes = new List<RichTextBox> { PurpleHomeTextBox, PurpleAccountTextBox, PurpleRewardsTextBox };

            if (dynamicColours)
            {
                greenPanels.ForEach(pannel => { pannel.BackColor = Color.MediumSeaGreen; });
                purplePannels.ForEach(pannel => { pannel.BackColor = Color.MidnightBlue; });
                purpleTextBoxes.ForEach(txtBox => { txtBox.BackColor = Color.MidnightBlue; });
                GreenHomeTextBox.BackColor = Color.MediumSeaGreen;
            }
            else
            {
                greenPanels.ForEach(pannel => { pannel.BackColor = Color.WhiteSmoke; });
                purplePannels.ForEach(pannel => { pannel.BackColor = Color.Gray; });
                purpleTextBoxes.ForEach(txtBox => { txtBox.BackColor = Color.Gray; });
                GreenHomeTextBox.BackColor = Color.WhiteSmoke;
            }
        }

        //Event handlers
        private void DynamicColourBtn_Click(object sender, EventArgs e)
       {
            bool dynamicColours;
            if(GreenAccountPannel.BackColor == Color.MediumSeaGreen)
            {
                DynamicColourBtn.Text = "Off";
                dynamicColours = false;
            }
            else
            {
                DynamicColourBtn.Text = "On";
                dynamicColours = true;
            }
            changeColours(dynamicColours);
       }

        private void LargeTextBtn_Click(object sender, EventArgs e)
        {
            bool largeText;
            if(HomeNavBtn.Font.SizeInPoints == 8.25)
            {
                LargeTextBtn.Text = "On";
                largeText = true;
            }
            else
            {
                LargeTextBtn.Text = "Off";
                largeText = false;
            }
        }

        private void EditAccountBtn_Click(object sender, EventArgs e)
        {

        }

        private void DeleteAccountBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
